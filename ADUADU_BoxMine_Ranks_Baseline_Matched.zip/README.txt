ADUADU BOXMINE SERVER PACK — 1.21.11

Rank glyphs:
\uE001 MEMBER
\uE002 VIP
\uE003 MVP
\uE004 MASTER
\uE005 MEDIA
\uE006 HELPER
\uE007 POLICE (gold badge design)
\uE008 ADMIN
\uE009 OWNER
\uE010 ADUADU BOXMINE (scoreboard title only)

The rank glyphs use minecraft:default so the same glyph can render in chat,
TAB, nametag/head text, and scoreboard text without specifying a custom font.

The pack does not change vanilla tools/items. It only adds font glyph textures.
