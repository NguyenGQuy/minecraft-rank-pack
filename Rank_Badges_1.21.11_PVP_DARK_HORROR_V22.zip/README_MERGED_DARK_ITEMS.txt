Merged resource pack for Minecraft 1.21.11.

Base: Rank Badges V9 Compact (ADMIN orange).
Added dark/gloomy item textures: golden apple, totem, elytra, potion, stick, cake.
Rank files and rank font files are preserved from the rank pack.
