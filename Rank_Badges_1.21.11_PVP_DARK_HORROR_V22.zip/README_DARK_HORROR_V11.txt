V11: PvP dark horror item textures. Rank files/font preserved from V10. Stick texture redesigned as a small dark sword with red accents.
