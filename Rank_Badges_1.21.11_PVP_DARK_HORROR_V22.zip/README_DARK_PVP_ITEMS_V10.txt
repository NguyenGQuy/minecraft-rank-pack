DARK SERVER PVP ITEMS V10

This pack keeps the existing rank system untouched and replaces only six item textures:
- Golden Apple
- Totem of Undying
- Elytra
- Potion
- Stick
- Cake

Style: compact PvP pixel art using the server screenshot palette: charcoal/black, steel gray, deep red, rust and orange accents.
Textures are 32x32 for sharper PvP visibility while remaining pixel-crisp.
Note: potion.png is the base potion texture and may affect other potion variants depending on Minecraft's item model setup.
