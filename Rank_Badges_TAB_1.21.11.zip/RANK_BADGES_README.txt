MINECRAFT RANK BADGES - 1.21.11

RESOURCE PACK:
1. Copy the folder contents of this ZIP into a resource pack folder, or use the ZIP directly.
2. Put the ZIP in .minecraft/resourcepacks and enable it.
3. The pack uses Resource Pack version 75.0 for Minecraft Java 1.21.11.

TAB:
Put the contents of TAB_groups_rank_badges.yml into plugins/TAB/groups.yml.
If groups.yml already has other groups, merge the rank entries instead of deleting your existing groups.

LuckPerms groups expected:
member, vip, mvp, master, helper, police, admin, owner

Glyphs:
MEMBER 
VIP 
MVP 
MASTER 
HELPER 
POLICE 
ADMIN 
OWNER 

After editing TAB:
- /tab reload

IMPORTANT:
TAB must manage nametags (change-nametag-prefix-suffix: true).
TAB can also manage tablist prefixes (change-tablist-prefix-suffix: true).
If you only want the badge above the player's head, keep tagprefix and remove/blank tabprefix.

The glyphs are private-use Unicode characters. Do not type them manually; use the supplied groups.yml.
