RANK PACK - Minecraft 1.21.11
==============================

9 rank badges extracted from the supplied design:
MEMBER  U+E001  \ue001
VIP     U+E002  \ue002
MVP     U+E003  \ue003
MASTER  U+E004  \ue004
HELPER  U+E005  \ue005
POLICE  U+E006  \ue006
MEDIA   U+E007  \ue007
ADMIN   U+E008  \ue008
OWNER   U+E009  \ue009

TAB groups.yml can use:
<font:minecraft:ranks>\ue001</font> through <font:minecraft:ranks>\ue009</font>

The pack uses a separate custom font file (minecraft:ranks), so it does not replace
Minecraft's normal default font.
