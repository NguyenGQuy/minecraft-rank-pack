ADUADU BOXMINE SERVER PACK — 1.21.11

Glyphs:
 ADU NGHÈO
 ADU GIÀU
 ADU SIÊU GIÀU
 ADU GIÀU NHẤT
 ADU MEDIA
 ADU HELPER
 ADU POLICE
 ADU ADMIN
 ADU OWNER
 ADUADU BOXMINE (scoreboard title only)

The rank glyphs use minecraft:default so the same glyph can render in chat,
TAB, nametag/head text, and scoreboard text without specifying a custom font.

The pack does not change vanilla tools/items. It only adds font glyph textures.
