Rank pack 1.21.11 - no custom icons.
MEDIA uses the same badge style as ADMIN.
Existing glyph/font files are preserved.
