RANK PIXEL + SCOREBOARD READY PACK
===================================
Original rank images are preserved.

Added:
- assets/minecraft/font/rankbadges.json
- TAB_groups.yml
- TAB_scoreboard.yml
- RANK_GLYPH_MAP.txt

Rank glyphs:
MEMBER 
VIP 
MVP 
MASTER 
HELPER 
POLICE 
MEDIA 
ADMIN 
OWNER 

Use the glyphs as LuckPerms prefixes as already configured.
TAB uses <font:rankbadges>...</font> to render the image.
Weights are not changed.

After replacing the pack on the server:
1. Keep the LuckPerms rank/weight settings.
2. Put TAB_groups.yml content into plugins/TAB/groups.yml.
3. Put TAB_scoreboard.yml content into the appropriate TAB scoreboard config.
4. /tab reload
