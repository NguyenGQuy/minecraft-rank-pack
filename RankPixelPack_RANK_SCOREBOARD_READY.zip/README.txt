This pack uses the rank badges cropped from the FIRST rank showcase generated earlier in the conversation, not the later hand-drawn replacement pack.

Ranks: MEMBER, VIP, MVP, MASTER, HELPER, POLICE, ADMIN, OWNER, MEDIA.
Each rank PNG is 200x70.
Scoreboard references are included separately.
